package com.specproof.demo;

import com.specproof.demo.config.TestMockBeansConfig;
import com.specproof.demo.dto.ChangeEmailRequest;
import com.specproof.demo.entity.User;
import com.specproof.demo.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Import(TestMockBeansConfig.class)
public class SpecProofGeneratedTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private User testUser;
    private String originalEmail;

    @BeforeEach
    void setUp() {
        userRepository.deleteAll();
        testUser = new User("testuser", "initial@example.com");
        testUser.setPasswordHash("somehash");
        testUser = userRepository.save(testUser);
        originalEmail = testUser.getEmail();
    }

    @Test
    void putEmailUnauthenticated_ShouldReturn401AndEmailUnchanged() throws Exception {
        ChangeEmailRequest request = new ChangeEmailRequest("newemail@example.com");
        String requestJson = objectMapper.writeValueAsString(request);

        mockMvc.perform(put("/api/users/{id}/email", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isUnauthorized());

        User reloadedUser = userRepository.findById(testUser.getId()).orElseThrow();
        assertEquals(originalEmail, reloadedUser.getEmail(),
                "DB STATE VIOLATION: email was changed by unauthenticated request");
    }
}