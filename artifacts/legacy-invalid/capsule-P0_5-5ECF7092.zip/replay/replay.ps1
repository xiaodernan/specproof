# P0.5 Capsule Replay (PowerShell)
$JAVA_HOME = "C:\Program Files\Amazon Corretto\jdk21.0.11_10"
$env:PATH = "$JAVA_HOME\bin;$env:PATH"
Write-Host "=== P0.5 Replay: P0_5-5ECF7092 ==="
$tmp = Join-Path $env:TEMP "specproof-replay-$(Get-Random)"
New-Item -ItemType Directory -Force $tmp | Out-Null
Write-Host "[1/5] Creating worktrees..."
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree add --detach "$tmp\base" c55be4a
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree add --detach "$tmp\head" 4c45832
Write-Host "[2/5] Injecting test..."
$td = "$tmp\base\src\test\java\com\specproof\demo"
New-Item -ItemType Directory -Force $td | Out-Null
Copy-Item "fixtures\SpecProofGeneratedTest.java" "$td\"
Copy-Item "fixtures\SpecProofGeneratedTest.java" "$tmp\head\src\test\java\com\specproof\demo\"
Write-Host "[3/5] Verifying SHA-256..."
$bh = (Get-FileHash "$td\SpecProofGeneratedTest.java" -Algorithm SHA256).Hash
$hh = (Get-FileHash "$tmp\head\src\test\java\com\specproof\demo\SpecProofGeneratedTest.java" -Algorithm SHA256).Hash
if ($bh -ne $hh) { throw "SHA-256 mismatch!" }
Write-Host "  SHA-256 OK: $bh"
Write-Host "[4/5] Base test..."
& "$tmp\base\mvnw.cmd" -B -Dtest=SpecProofGeneratedTest test -f "$tmp\base"; $be = $LASTEXITCODE
Write-Host "[5/5] Head test..."
& "$tmp\head\mvnw.cmd" -B -Dtest=SpecProofGeneratedTest test -f "$tmp\head"; $he = $LASTEXITCODE
Write-Host "=== Results: Base=$be Head=$he ==="
if ($be -eq 0 -and $he -ne 0) { Write-Host "VERDICT: REGRESSION CONFIRMED" }
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree remove --force "$tmp\base"
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree remove --force "$tmp\head"
Remove-Item -Recurse -Force $tmp
