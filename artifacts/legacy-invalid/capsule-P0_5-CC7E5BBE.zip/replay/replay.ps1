# P0.5 Capsule Replay Script (PowerShell)
# Finding: P0_5-CC7E5BBE
# Severity: MAJOR
$JAVA_HOME = "C:\Program Files\Amazon Corretto\jdk21.0.11_10"
$env:PATH = "$JAVA_HOME\bin;$env:PATH"

Write-Host "=== P0.5 Capsule Replay: P0_5-CC7E5BBE ==="

# Step 1: Create temp worktrees
$tmp = Join-Path $env:TEMP "specproof-replay-$(Get-Random)"
New-Item -ItemType Directory -Force $tmp | Out-Null

Write-Host "[1/5] Creating worktrees..."
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree add --detach "$tmp\base" c55be4a
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree add --detach "$tmp\head" 4c45832

# Step 2: Inject test
Write-Host "[2/5] Injecting test..."
$testDir = "$tmp\base\src\test\java\com\specproof\demo"
New-Item -ItemType Directory -Force $testDir | Out-Null
Copy-Item "fixtures\SpecProofGeneratedTest.java" "$testDir\"
Copy-Item "fixtures\SpecProofGeneratedTest.java" "$tmp\head\src\test\java\com\specproof\demo\"

# Step 3: Verify SHA-256
Write-Host "[3/5] Verifying test SHA-256..."
$baseHash = (Get-FileHash "$testDir\SpecProofGeneratedTest.java" -Algorithm SHA256).Hash
$headHash = (Get-FileHash "$tmp\head\src\test\java\com\specproof\demo\SpecProofGeneratedTest.java" -Algorithm SHA256).Hash
if ($baseHash -ne $headHash) { throw "SHA-256 mismatch!" }
Write-Host "  SHA-256: $baseHash"

# Step 4: Run tests
Write-Host "[4/5] Running base test..."
& "$tmp\base\mvnw.cmd" -B -Dtest=SpecProofGeneratedTest test -f "$tmp\base"
$baseExit = $LASTEXITCODE

Write-Host "[5/5] Running head test..."
& "$tmp\head\mvnw.cmd" -B -Dtest=SpecProofGeneratedTest test -f "$tmp\head"
$headExit = $LASTEXITCODE

# Report
Write-Host "=== Results ==="
Write-Host "Base exit: $baseExit"
Write-Host "Head exit: $headExit"
if ($baseExit -eq 0 -and $headExit -ne 0) {
    Write-Host "VERDICT: REGRESSION CONFIRMED - P0.5 PASS"
} else {
    Write-Host "VERDICT: NON_REPRODUCIBLE"
}

# Cleanup
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree remove --force "$tmp\base"
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree remove --force "$tmp\head"
Remove-Item -Recurse -Force $tmp
