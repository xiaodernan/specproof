package com.specproof.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Import(com.specproof.demo.TestMockBeansConfig.class)
class SpecProofGeneratedTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User(null, "testuser", "original@example.com", "hashedpassword");
        testUser = userRepository.save(testUser);
    }

    @Test
    void unauthenticatedEmailChangeShouldReturn401AndNotModifyDb() throws Exception {
        String newEmail = "new.email@example.com";
        String initialEmail = testUser.getEmail();

        ChangeEmailRequest request = new ChangeEmailRequest();
        request.setNewEmail(newEmail);

        mockMvc.perform(put("/api/users/{id}/email", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized());

        User reloadedUser = userRepository.findById(testUser.getId()).orElseThrow();
        assertEquals(initialEmail, reloadedUser.getEmail(),
                "The user's email should not have been changed by an unauthenticated request");
    }
}