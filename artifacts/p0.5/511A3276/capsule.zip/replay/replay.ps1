# P0.5 Capsule Replay — P0_5-511A3276
$ErrorActionPreference = "Stop"
$JAVA_HOME = "C:\Program Files\Amazon Corretto\jdk21.0.11_10"
$env:PATH = "$JAVA_HOME\bin;$env:PATH"
Write-Host "=== P0.5 Capsule Replay: P0_5-511A3276 ==="
$tmp = Join-Path $env:TEMP "specproof-replay-$(Get-Random)"
New-Item -ItemType Directory -Force $tmp | Out-Null
Write-Host "[1/5] Worktrees..."
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree add --detach "$tmp\base" c55be4a
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree add --detach "$tmp\head" 4c45832
Write-Host "[2/5] Injecting test..."
$td = "$tmp\base\src\test\java\com\specproof\demo"
New-Item -ItemType Directory -Force $td | Out-Null
Copy-Item "fixtures\SpecProofGeneratedTest.java" "$td\"
Copy-Item "fixtures\SpecProofGeneratedTest.java" "$tmp\head\src\test\java\com\specproof\demo\"
$baseHash = (Get-FileHash "$td\SpecProofGeneratedTest.java" -Algorithm SHA256).Hash
$headHash = (Get-FileHash "$tmp\head\src\test\java\com\specproof\demo\SpecProofGeneratedTest.java" -Algorithm SHA256).Hash
if ($baseHash -ne $headHash) { throw "SHA-256 MISMATCH: base=$baseHash head=$headHash" }
Write-Host "[3/5] SHA-256: $baseHash"
Write-Host "[4/5] Base test (expect PASS — 401 + DB unchanged)..."
& "$tmp\base\mvnw.cmd" -B -Dtest=SpecProofGeneratedTest test "-Dmaven.test.failure.ignore=false" -f "$tmp\base"
$baseExit = $LASTEXITCODE
Write-Host "[5/5] Head test (expect FAIL — 200 + DB changed)..."
& "$tmp\head\mvnw.cmd" -B -Dtest=SpecProofGeneratedTest test "-Dmaven.test.failure.ignore=false" -f "$tmp\head"
$headExit = $LASTEXITCODE
Write-Host "=== RESULTS ==="
Write-Host "BASE exit: $baseExit (expect 0)"
Write-Host "HEAD exit: $headExit (expect non-zero)"
if ($baseExit -eq 0 -and $headExit -ne 0) {
    Write-Host "VERDICT: REGRESSION CONFIRMED"
} else {
    Write-Host "VERDICT: NON_REPRODUCIBLE"
}
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree remove --force "$tmp\base" 2>$null
git -C "D:\experim\specproof-phase0\demo\spring-backend" worktree remove --force "$tmp\head" 2>$null
Remove-Item -Recurse -Force $tmp
